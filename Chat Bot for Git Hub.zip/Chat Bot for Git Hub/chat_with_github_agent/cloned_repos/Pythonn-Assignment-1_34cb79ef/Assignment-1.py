m1=float(input("Enter the marks 1 : "))
m2=float(input("Enter the marks 2 : "))
m3=float(input("Enter the marks 3 : "))
print("The mark 1 is : ",m1)
print("The mark 2 is : ",m2)
print("The mark 3 is : ",m3)
c=m1+m2+m3
avg=c/3
print("THe average of mark1, mark2 and mark3 is : ",avg)
"""
Output:
Enter the marks 1 : 20
Enter the marks 2 : 20
Enter the marks 3 : 19
The mark 1 is :  20.0
The mark 2 is :  20.0
The mark 3 is :  19.0
THe average of mark1, mark2 and mark3 is :  19.666666666666668
"""